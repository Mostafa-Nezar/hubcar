<?php

namespace App\Filament\Exports;

use App\Models\BookingRequest;
use Filament\Actions\Exports\ExportColumn;
use Filament\Actions\Exports\Exporter;
use Filament\Actions\Exports\Models\Export;
use Illuminate\Support\Number;

class BookingRequestExporter extends Exporter
{
    protected static ?string $model = BookingRequest::class;

    public static function getColumns(): array
    {
        return [
            ExportColumn::make('id')
                ->label('ID'),
            ExportColumn::make('payment_type'),
            ExportColumn::make('client_name'),
            ExportColumn::make('phone'),
            ExportColumn::make('car_id'),
            ExportColumn::make('car_name_manual'),
            ExportColumn::make('model_year'),
            ExportColumn::make('city'),
            ExportColumn::make('request_date'),
            ExportColumn::make('status'),
            ExportColumn::make('state_category'),
            ExportColumn::make('bank_name'),
            ExportColumn::make('work_sector'),
            ExportColumn::make('monthly_salary'),
            ExportColumn::make('client_notes'),
            ExportColumn::make('internal_notes'),
            ExportColumn::make('updated_by'),
            ExportColumn::make('last_status_update'),
            ExportColumn::make('created_at'),
            ExportColumn::make('updated_at'),
        ];
    }

    public static function getCompletedNotificationBody(Export $export): string
    {
        $body = 'Your booking request export has completed and ' . Number::format($export->successful_rows) . ' ' . str('row')->plural($export->successful_rows) . ' exported.';

        if ($failedRowsCount = $export->getFailedRowsCount()) {
            $body .= ' ' . Number::format($failedRowsCount) . ' ' . str('row')->plural($failedRowsCount) . ' failed to export.';
        }

        return $body;
    }
}
