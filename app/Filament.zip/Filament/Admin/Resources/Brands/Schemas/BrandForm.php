<?php

namespace App\Filament\Admin\Resources\Brands\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class BrandForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->label('اسم الشركة')
                    ->required()
                    ->unique(ignoreRecord: true),
                FileUpload::make('logo')
                    ->label('الشعار')
                    ->image()
                    ->directory('brands'),
            ]);
    }
}
