<?php

namespace App\Filament\Admin\Resources\BookingRequests\Schemas;

use Filament\Schemas\Schema;

class BookingRequestInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
