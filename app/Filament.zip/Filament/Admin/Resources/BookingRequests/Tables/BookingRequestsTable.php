<?php

namespace App\Filament\Admin\Resources\BookingRequests\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Filament\Actions\ExportAction;
use App\Filament\Exports\BookingRequestExporter;

class BookingRequestsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->label('رقم الطلب')
                    ->sortable(),
                TextColumn::make('payment_type')
                    ->label('نوع الدفع')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'cash' => 'success',
                        'finance' => 'warning',
                        default => 'gray',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'cash' => 'كاش',
                        'finance' => 'تمويل',
                        default => $state,
                    }),
                TextColumn::make('client_name')
                    ->label('اسم العميل')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('phone')
                    ->label('الجوال')
                    ->searchable(),
                TextColumn::make('car.name')
                    ->label('السيارة')
                    ->placeholder(fn ($record) => $record->car_name_manual ?? '---'),
                TextColumn::make('model_year')
                    ->label('الموديل'),
                TextColumn::make('city')
                    ->label('المدينة'),
                TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'New' => 'info',
                        'Contacted' => 'warning',
                        'Interested' => 'success',
                        'Not Interested' => 'danger',
                        'Completed' => 'primary',
                        default => 'gray',
                    }),
                TextColumn::make('request_date')
                    ->label('التاريخ')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                SelectFilter::make('payment_type')
                    ->label('نوع الدفع')
                    ->options([
                        'cash' => 'كاش',
                        'finance' => 'تمويل',
                    ]),
                SelectFilter::make('status')
                    ->label('الحالة')
                    ->options([
                        'New' => 'جديد',
                        'Contacted' => 'تم التواصل',
                        'Interested' => 'مهتم',
                        'Not Interested' => 'غير مهتم',
                        'Completed' => 'مكتمل',
                    ]),
            ])
            ->recordActions([
                ViewAction::make(),
                EditAction::make(),
            ])
            ->headerActions([
                ExportAction::make()
                    ->exporter(BookingRequestExporter::class)
                    ->label('تصدير إكسل'),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
