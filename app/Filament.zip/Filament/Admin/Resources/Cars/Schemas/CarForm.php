<?php

namespace App\Filament\Admin\Resources\Cars\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Repeater;
use Filament\Schemas\Schema;

class CarForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('معلومات أساسية')
                    ->schema([
                        Grid::make(2)
                            ->schema([
                                TextInput::make('name')
                                    ->label('اسم السيارة')
                                    ->required(),
                                Select::make('brand_id')
                                    ->label('الشركة المصنعة')
                                    ->relationship('brand', 'name')
                                    ->required()
                                    ->searchable()
                                    ->preload(),
                                TextInput::make('type')
                                    ->label('نوع السيارة')
                                    ->placeholder('مثل: SUV, Sedan')
                                    ->required(),
                                TextInput::make('category')
                                    ->label('الفئة')
                                    ->placeholder('مثل: Luxury, Economy'),
                                TextInput::make('model_year')
                                    ->label('سنة الموديل')
                                    ->numeric()
                                    ->required(),
                                TextInput::make('price')
                                    ->label('السعر')
                                    ->numeric()
                                    ->prefix('SAR')
                                    ->required(),
                            ]),
                    ]),

                Section::make('الحالة والمواصفات')
                    ->schema([
                        Grid::make(3)
                            ->schema([
                                Select::make('condition')
                                    ->label('الحالة')
                                    ->options([
                                        'new' => 'جديدة',
                                        'used' => 'مستعملة',
                                    ])
                                    ->default('new')
                                    ->required(),
                                Select::make('availability_status')
                                    ->label('حالة التوفر')
                                    ->options([
                                        'available' => 'متوفرة',
                                        'sold' => 'مباعة',
                                        'reserved' => 'محجوزة',
                                    ])
                                    ->default('available')
                                    ->required(),
                                Toggle::make('is_featured')
                                    ->label('عرض في الواجهة')
                                    ->default(false),
                            ]),
                        Grid::make(3)
                            ->schema([
                                TextInput::make('seats')
                                    ->label('عدد المقاعد')
                                    ->numeric(),
                                TextInput::make('transmission')
                                    ->label('ناقل الحركة')
                                    ->placeholder('مثل: Automatic, Manual'),
                                TextInput::make('fuel_type')
                                    ->label('نوع الوقود')
                                    ->placeholder('مثل: Gasoline, Hybrid, Electric'),
                            ]),
                    ]),

                Section::make('الصور والوسائط')
                    ->schema([
                        FileUpload::make('main_image')
                            ->label('الصورة الرئيسية')
                            ->image()
                            ->directory('cars')
                            ->required(),
                        Repeater::make('images')
                            ->label('معرض الصور')
                            ->relationship('images')
                            ->schema([
                                FileUpload::make('path')
                                    ->label('الصورة')
                                    ->image()
                                    ->directory('cars/gallery')
                                    ->required(),
                                TextInput::make('sort_order')
                                    ->label('الترتيب')
                                    ->numeric()
                                    ->default(0),
                            ])
                            ->columns(2)
                            ->grid(2),
                    ]),

                Section::make('الوصف والمواصفات التفصيلية')
                    ->schema([
                        Textarea::make('description')
                            ->label('الوصف')
                            ->rows(5),
                        Textarea::make('other_specs')
                            ->label('مواصفات إضافية')
                            ->rows(3),
                    ]),
            ]);
    }
}
